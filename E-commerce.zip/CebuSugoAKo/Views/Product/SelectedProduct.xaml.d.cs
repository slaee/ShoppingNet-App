using System;
using Xamarin.Forms;
namespace Shop.Product
{
	public partial class SelectedProduct
	{
		void InitializeComponent()
		{
			Xamarin.Forms.Xaml.Extensions.LoadFromXaml(this, typeof(SelectedProduct));
		}
	}
}
