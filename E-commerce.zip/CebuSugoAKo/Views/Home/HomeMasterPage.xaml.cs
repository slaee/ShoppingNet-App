using System;
using System.IO;
using Xamarin.Forms;

namespace Shop.Views
{
	public partial class HomeMasterPage : MasterDetailPage
	{
		public HomeMasterPage()
		{
			InitializeComponent();
		}
	}
}