using System;
using Xamarin.Forms;
namespace Shop.Views
{
	public partial class Home
	{
		void InitializeComponent()
		{
			Xamarin.Forms.Xaml.Extensions.LoadFromXaml(this, typeof(Home));
		}
	}
}
