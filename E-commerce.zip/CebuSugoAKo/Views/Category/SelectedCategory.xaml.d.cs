using System;
using Xamarin.Forms;
namespace Shop.Category
{
	public partial class SelectedCategory
	{
		void InitializeComponent()
		{
			Xamarin.Forms.Xaml.Extensions.LoadFromXaml(this, typeof(SelectedCategory));
		}
	}
}
