using System;
using System.IO;
using Xamarin.Forms;

namespace Shop.Category
{
	public partial class SelectedCategory : ContentPage
	{
		public SelectedCategory()
		{
			InitializeComponent();
		}
	}
}