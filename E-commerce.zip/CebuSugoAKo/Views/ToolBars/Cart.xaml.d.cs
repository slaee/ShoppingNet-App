using System;
using Xamarin.Forms;
namespace Shop.Views
{
	public partial class Cart
	{
		void InitializeComponent()
		{
			Xamarin.Forms.Xaml.Extensions.LoadFromXaml(this, typeof(Cart));
		}
	}
}
