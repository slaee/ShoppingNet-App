namespace Shop.Model
{
    public class CarouselImageData
    {
        public string ImageUrl { get; set; }
        public bool IsFavor { get; set; }
    }
}