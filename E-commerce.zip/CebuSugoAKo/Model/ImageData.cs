namespace Shop.Model
{
    public class ImageData 
    {
        public string ImageSource { get; set; }
        public bool IsFavorite { get; set; }
        public bool btn1Visible { get; set; }
        public bool btn2Visible { get; set; }
    }
}