namespace Shop.Model
{
    public class CartItems 
    {
        public string icon { get; set; }
    }
}